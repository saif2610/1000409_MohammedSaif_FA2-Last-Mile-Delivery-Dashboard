import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(
    page_title="Last Mile Delivery Dashboard",
    page_icon="🚚",
    layout="wide"
)

st.title("🚚 Last Mile Delivery Dashboard")
st.caption("Analyzing Last Mile Delivery Data for Performance Insights")

# Load the user's dataset
df = pd.read_csv("delivery_data.csv")

# -----------------------------
# DATA OVERVIEW
# -----------------------------
st.header("1. Dataset Overview")

col1, col2 = st.columns(2)

with col1:
    st.metric("Total Records", f"{len(df):,}")

with col2:
    st.metric("Total Columns", len(df.columns))

st.subheader("First 5 Records")
st.dataframe(df.head(), use_container_width=True)

# -----------------------------
# DATA CLEANING
# -----------------------------
st.header("2. Data Cleaning")

# Convert important numeric columns
for column in ["Delivery_Time", "Agent_Rating", "Agent_Age"]:
    if column in df.columns:
        df[column] = pd.to_numeric(df[column], errors="coerce")

# Fill missing numeric values with median
if "Agent_Rating" in df.columns:
    df["Agent_Rating"] = df["Agent_Rating"].fillna(df["Agent_Rating"].median())

# Fill missing weather with the most common value
if "Weather" in df.columns:
    df["Weather"] = df["Weather"].fillna(df["Weather"].mode()[0])

# Show missing values after cleaning
missing = df.isnull().sum()
missing = missing[missing > 0]

if len(missing) == 0:
    st.success("No remaining missing values in the main fields.")
else:
    st.dataframe(missing.to_frame("Missing Values"))

# -----------------------------
# DELIVERY METRICS
# -----------------------------
st.header("3. Delivery Performance")

average_delivery_time = df["Delivery_Time"].mean()
std_delivery_time = df["Delivery_Time"].std()

# FA-2 definition: late if delivery time > mean + 1 standard deviation
late_threshold = average_delivery_time + std_delivery_time

df["Late_Delivery"] = df["Delivery_Time"] > late_threshold

late_percentage = df["Late_Delivery"].mean() * 100

c1, c2, c3 = st.columns(3)

with c1:
    st.metric("Average Delivery Time", f"{average_delivery_time:.2f} min")

with c2:
    st.metric("Late Delivery %", f"{late_percentage:.2f}%")

with c3:
    st.metric("Late Delivery Threshold", f"{late_threshold:.2f} min")

# -----------------------------
# AGENT AGE GROUP
# -----------------------------
def age_group(age):
    if pd.isna(age):
        return "Unknown"
    if age < 25:
        return "Under 25"
    elif age <= 40:
        return "25–40"
    return "40+"

if "Agent_Age" in df.columns:
    df["Agent_Age_Group"] = df["Agent_Age"].apply(age_group)

# -----------------------------
# CLEANED DATA
# -----------------------------
st.header("4. Cleaned Dataset")
st.dataframe(df.head(20), use_container_width=True)
